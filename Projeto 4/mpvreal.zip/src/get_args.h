#ifndef GET_ARGS_H
#define GET_ARGS_H

#define PREFIX '-'

char* getArg(int argc, char* argv[], char* arg);

#endif