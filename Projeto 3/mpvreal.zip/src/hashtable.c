#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "hashtable.h"

#define MAGIC_HASH 5381UL

/**************
*Parte privada*
**************/

typedef struct Node{

    char* key;
    Data data;

    struct Node* next;

} Node_t;

typedef struct HashTable{

    Node_t* nodeArray[TABLE_SIZE];

} Hash_t;

/**************
*Parte pública*
**************/

HashTable newHashTable(){

    Hash_t* hashTable = (Hash_t*) malloc(sizeof(Hash_t));

    for(unsigned int i = 0; i < TABLE_SIZE; i++)
        hashTable->nodeArray[i] = NULL;

    return hashTable;
}

Node newNode(char* key, Data data){

    Node_t* node = (Node_t*) malloc(sizeof(Node_t));

    node->key = (char*) calloc(strlen(key) + 1, sizeof(char));
    node->key = strncpy(node->key, key, strlen(key) + 1);

    node->data = data;

    node->next = NULL;

    return node;
}

Node getHashNodeNext(Node node){

    if(node == NULL)
        return NULL;

    Node_t* toGet = (Node_t*) node;

    return toGet->next;
}

Node* getNodeArray(HashTable table){

    if(table == NULL)
        return NULL;

    Hash_t* toGet = (Hash_t*) table;

    return (Node*) toGet->nodeArray;
}

Data searchKey(HashTable table, char* key){

    if(key == NULL)
        return NULL;

    Hash_t* hashTable = (Hash_t*) table;

    Node_t* buffer = hashTable->nodeArray[hashCode(key)];

    while(buffer && strcmp(key, buffer->key))
        buffer = buffer->next;

    if(buffer)
        return buffer->data;
    else
        return NULL;
}

Data getHashNodeData(Node node){

    if(node == NULL)
        return NULL;

    Node_t* toGet = (Node_t*) node;

    return toGet->data;
}

char* getHashNodeKey(Node node){

    if(node == NULL)
        return NULL;

    Node_t* toGet = (Node_t*) node;

    return toGet->key;
}

unsigned int hashCode(char* key){

    if(key == NULL)
        return 0;

    unsigned long hash = MAGIC_HASH;
    char ch;

    while((ch = *key++))
        hash = ((hash << 5) + hash) + ch;

    return (hash % TABLE_SIZE);
}

void insertHashNode(HashTable table, char* key, Data data){

    Hash_t* hashTable = (Hash_t*) table;
    Node_t* toAdd = (Node_t*) newNode(key, data), *buffer;

    buffer = hashTable->nodeArray[hashCode(toAdd->key)];

    if(buffer == NULL)
        hashTable->nodeArray[hashCode(toAdd->key)] = toAdd;
        
    else{

        while(buffer->next)
            buffer = buffer->next;

        buffer->next = toAdd;
    }
}

void delNode(HashTable table, char* key, void (*freeData)(Data)){

    Hash_t* hashTable = (Hash_t*) table;

    Node_t* buffer = hashTable->nodeArray[hashCode(key)],
          * buffer_2 = NULL;

    while(buffer && strcmp(key, buffer->key)){

        buffer_2 = buffer;
        buffer = buffer->next;
    }

    if(buffer == NULL)
        return;

    if(buffer_2)
        buffer_2->next = buffer->next;
    else
        hashTable->nodeArray[hashCode(key)] = buffer->next;

    freeData(buffer->data);

    free(buffer->key);

    free(buffer);
}

void printHashTable(HashTable table){

    if(table == NULL)
        return;

    Node_t* buffer = NULL;
    Hash_t* hashTable = (Hash_t*) table;

    for(unsigned int i = 0; i < TABLE_SIZE; i++){
        
        printf("[%d] ", i);

        buffer = hashTable->nodeArray[i];

        while(buffer){

            printf("-> \"%p\" ", buffer->data);

            buffer = buffer->next;
        }

        printf("\n");
    }
}

void freeNode(Node node, void (*freeData)(Data)){

    Node_t* toFree = (Node_t*) node;

    free(toFree->key);
    freeData(toFree->data);

    free(toFree);
}

void freeHashTable(HashTable table, void (*freeData)(Data)){

    Hash_t* hashTable = (Hash_t*) table;
    Node_t* node, *buffer;

    for(unsigned int i = 0; i < TABLE_SIZE; i++){

        node = hashTable->nodeArray[i];

        while(node){

            buffer = node->next;

            freeNode(node, freeData);

            node = buffer;
        }
    }

    free(hashTable);
}