#ifndef CITY_H
#define CITY_H

#include "types.h"

City newCity();

Tree getCityBlocks(City city);

HashTable getCityCepMap(City city);

HashTable getCityInhabitants(City city);

HashTable getCityTenancies(City city);

void destroyCity(City city);

#endif