#ifndef HASHTABLE_H
#define HASHTABLE_H

#define TABLE_SIZE 100U

#include "types.h"

HashTable newHashTable();

Node newNode(char* key, Data data);

Node getHashNodeNext(Node node);

Node* getNodeArray(HashTable table);

Data searchKey(HashTable table, char* key);

Data getHashNodeData(Node node);

char* getHashNodeKey(Node node);

unsigned int hashCode(char* key);

void insertHashNode(HashTable table, char* key, Data data);

void delNode(HashTable table, char* key, void (*freeData)(Data));

void printNode(Node node);

void printHashTable(HashTable table);

void freeNode(Node node, void (*freeData)(Data));

void freeHashTable(HashTable table, void (*freeData)(Data));

#endif