#include <stdlib.h>

#include "hashtable.h"
#include "city.h"
#include "avltree.h"
#include "list.h"
#include "buildings.h"

/**************
*Parte privada*
**************/

typedef struct City{

    Tree blocks;
    HashTable cepMap;
    HashTable inhabitants;
    HashTable tenancies;

} City_t;

static void dummy(void* ptr){}

/**************
*Parte pública*
**************/

City newCity(){

    City_t* city = (City_t*) malloc(sizeof(City_t));

    city->blocks = newTree();
    city->cepMap = newHashTable();
    city->inhabitants = newHashTable();
    city->tenancies = newHashTable();

    return city;
}

Tree getCityBlocks(City city){

    if(city == NULL)
        return NULL;

    City_t* toGet = (City_t*) city;

    return toGet->blocks;
}

HashTable getCityCepMap(City city){

    if(city == NULL)
        return NULL;

    City_t* toGet = (City_t*) city;

    return toGet->cepMap;
}

HashTable getCityInhabitants(City city){

    if(city == NULL)
        return NULL;

    City_t* toGet = (City_t*) city;

    return toGet->inhabitants;
}

HashTable getCityTenancies(City city){

    if(city == NULL)
        return NULL;
    
    City_t* toGet = (City_t*) city;

    return toGet->tenancies;
}

void destroyCity(City city){

    if(city == NULL)
        return;

    City_t* toDestroy = (City_t*) city;

    chopTree(toDestroy->blocks, freeList, dummy);
    freeHashTable(toDestroy->tenancies, dummy);
    freeHashTable(toDestroy->inhabitants, freePerson);
    freeHashTable(toDestroy->cepMap, freeBlock);

    free(toDestroy);
}