#ifndef GETWORD_H
#define GETWORD_H

#include <stdio.h>

char* getword(char* destination, FILE* stream);

#endif